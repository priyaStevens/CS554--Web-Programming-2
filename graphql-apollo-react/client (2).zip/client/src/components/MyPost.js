import React, { useState } from 'react';
import './App.css';
import AddModal from './modals/AddModal';
import { useQuery } from '@apollo/client';
import queries from '../queries';

function MyPost() {

    const [showEditModal, setShowEditModal] = useState(false);
    const [showAddModal, setShowAddModal] = useState(false);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const { loading, error, data } = useQuery(queries.Get_MyPostData, {
        fetchPolicy: 'cache-and-network'
      });
  
    const handleCloseModals = () => {
        setShowEditModal(false);
        setShowDeleteModal(false);
        setShowAddModal(false);
      };

      const handleOpenAddModal = () => {
        setShowAddModal(true);
      };

      if(data){
        const myPostImageData = data['userPostedImages'];
       return( 
        <div>
        <button className="button" onClick={handleOpenAddModal}>
          Upload Images
        </button>
        <br />
        <br />

        return (
          <div class = "col-12 col-xl-12 .col-lg-12 col-md-12">
          {myPostImageData.map((myPostImage)=>{
            return(
              <div className="card" key={myPostImage.id}>
              <h5 className="card-header">
                    {myPostImage.description} by {myPostImage.posterName}
              </h5>
              <div className="card-body">
                  
                    <br/>
                    <img src={myPostImage.url} width="600" height="auto" />
                  <br />
                  <br />
                </div>
                <div class="card-footer">
                <button type="button" class="btn btn-danger btn-lg">Add to bin </button>
                </div>
              </div>
            )
          })  
    
          }  
          
          {/*Add Employee Modal */}
        {showAddModal && showAddModal && (
          <AddModal
            isOpen={showAddModal}
            handleClose={handleCloseModals}
            modal="uploadImage"
          />
        )}
    </div>
    );
    </div> )} else if (loading) {
      return <div>Loading</div>;
    } else if (error) {
      return <div>{error.message}</div>;
    }
}


export default MyPost;