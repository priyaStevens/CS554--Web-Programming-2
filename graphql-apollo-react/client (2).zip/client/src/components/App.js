import React from 'react';
import './App.css';
import { NavLink, BrowserRouter as Router, Route } from 'react-router-dom';
import UnSplashImageData from './Home';
import MyBin from './MyBin';
import MyPost from './MyPost'
import {
  ApolloClient,
  HttpLink,
  InMemoryCache,
  ApolloProvider
} from '@apollo/client';
const client = new ApolloClient({
  cache: new InMemoryCache(),
  link: new HttpLink({
    uri: 'http://localhost:4000'
  })
});

function App() {
  return (
    <ApolloProvider client={client}>
      <Router>
        <div>
          <header className="App-header">
            <h1 className="App-title">
              GraphQL With Apollo Client/Server Demo
            </h1>
            <nav>
              <NavLink className="navlink" to="/">
              UnSplashImageData
              </NavLink>
              <NavLink className="navlink" to="/myBin">
                MyBin
              </NavLink>

              <NavLink className="navlink" to="/myPost">
                MyPost
              </NavLink>
            </nav>
          </header>
          <Route exact path="/" component={UnSplashImageData} />
          <Route path="/myBin/" component={MyBin} />
          <Route path="/myPost/" component={MyPost} />
        </div>
      </Router>
    </ApolloProvider>
  );
}

export default App;
