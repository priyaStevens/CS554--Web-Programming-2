import React, { useState } from 'react';
import './App.css';
import { useQuery, useMutation } from '@apollo/client';
import queries from '../queries';

function UnSplashImageData(props) {
  // let pageNumber = 1;
  const[pageNumber, setPageNumber] = useState(1);
  const[buttonText, setButtonText] = useState('Add to bin');
    const { loading, error, data } = useQuery(queries.GET_UnsplashData, {
        variables :{pageNum:pageNumber},
        fetchPolicy: 'cache-and-network'
      });

      const [AddtoBin] = useMutation(queries.Edit_Image,{
        refetchQueries: [{ query: queries.GET_UnsplashData}],
          awaitRefetchQueries: true,
      });

// const [AddtoBin] = useMutation(queries.Add_NewPost, {
//   refetchQueries: [{ query: queries.GET_ALL_USER_POST}],
//   awaitRefetchQueries: true,
// });

const handleMoreImages = () => {
 setPageNumber(pageNumber+1);
};

const setButtonTextonClick = (image) => {
 setButtonText("Added to bin");
};


if(data){
    const unSplashImagesData = data['unsplashImages'];

    return (

      <div>  
        <br />
        <br />
      <div class = "col-12 col-xl-12 .col-lg-12 col-md-12">

      <button className="button" onClick={handleMoreImages}>
      Load More Images
    </button>
      {unSplashImagesData.map((unSplashImages)=>{
        return(
          <div className="card" key={unSplashImages.id}>
          <h5 className="card-header">
                {unSplashImages.description} by {unSplashImages.posterName}
          </h5>
          <div className="card-body">
              
                <br/>
                <img src={unSplashImages.url} width="600" height="auto" />
              <br />
              <br />

              <form
              className="form"
              id="edit-myPost"
              onSubmit={(e) => {
                e.preventDefault();
                AddtoBin({
                  variables: {
                    url: unSplashImages.url,
                    description: unSplashImages.description,
                    posterName: unSplashImages.posterName,
                    id: unSplashImages.id,
                    binned: unSplashImages.binned,
                    userPosted: unSplashImages.userPosted
                  }
                });
                alert('yes');
              }
            }
                >  
                <br/>
                <br/>  
                <button className="button add-button" type="submit">
                {unSplashImages.binned == false ? 'Add to bin' : 'Added to bin'}
              </button>
            </form>
            </div>
          </div>
        )
      })  

      }
        
          

      </div>
      </div>
);
} else if (loading) {
  return <div>Loading</div>;
} else if (error) {
  return <div>{error.message}</div>;
}
}

      
    

export default UnSplashImageData;