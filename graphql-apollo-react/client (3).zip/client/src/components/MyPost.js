import React, { useState } from 'react';
import './App.css';
import AddModal from './modals/AddModal';
import DeleteModal from './modals/DeleteModal'
import { useQuery } from '@apollo/client';
import queries from '../queries';

function MyPost() {

    const [showEditModal, setShowEditModal] = useState(false);
    const [showAddModal, setShowAddModal] = useState(false);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [deleteImage, setdeleteImage] = useState(null);
    
    const { loading, error, data } = useQuery(queries.Get_MyPostData, {
        fetchPolicy: 'cache-and-network'
      });

      console.log(data);
  
    const handleCloseModals = () => {
        setShowEditModal(false);
        setShowDeleteModal(false);
        setShowAddModal(false);
      };

      const handleOpenAddModal = () => {
        setShowAddModal(true);
      };

      const handleOpenDeleteModal = (image) => {
        setShowDeleteModal(true);
        setdeleteImage(image);
      };

      if(data){
        const myPostImageData = data['userPostedImages'];
       return( 
        <div>
        <button className="button" onClick={handleOpenAddModal}>
          Upload Images
        </button>
        <br />
        <br />
          <div class = "col-12 col-xl-12 .col-lg-12 col-md-12">
          {myPostImageData.map((myPostImage)=>{
            if(myPostImage != null){
            return(
              <div className="card" key={myPostImage!=null ? myPostImage.id : ''}>
              <h5 className="card-header">
                    {myPostImage.description !=null ? myPostImage.description:''} by {myPostImage.posterName? myPostImage.posterName:''}
              </h5>
              <div className="card-body">
                  
                    <br/>
                    <img src={myPostImage.url? myPostImage.url:''} width="600" height="auto" />
                  <br />
                  <br />
                </div>
                <div class="card-footer">
                <button type="button" class="btn btn-danger btn-md">Add to bin </button>
                <button
                  className="button" 
                  onClick={() => {
                    handleOpenDeleteModal(myPostImage);
                  }}
                  class="btn btn-primary btn-md">
                  Delete
                </button>
                </div>
                <br />
              </div>
            )}
          })  
    
          }  
          
          {/*Add Image Modal */}
        {showAddModal && showAddModal && (
          <AddModal
            isOpen={showAddModal}
            handleClose={handleCloseModals}
            modal="uploadImage"
          />
        )}
    {/*Delete Image Modal */}
    {showDeleteModal && showDeleteModal && (
      <DeleteModal
        isOpen={showDeleteModal}
        handleClose={handleCloseModals}
        deleteEmployee={deleteImage}
      />
    )}

    </div>
    </div> )
  } 
    else if (loading) {
      return <div>Loading</div>;
    } else if (error) {
      return <div>{error.message}</div>;
    }
}


export default MyPost;