import React, { useState } from 'react';
import './App.css';
import { useQuery } from '@apollo/client';
import queries from '../queries';

function MyBin() {

    return (
        <div>
        this is the BIN
        </div>
    )
}

export default MyBin;