import { gql } from '@apollo/client';

const Add_NewPost = gql`
mutation uploadImagePost(
  $url: String!
  $description: String
  $posterName: String 
){
  uploadImage(url:$url, description: $description, posterName: $posterName){
    id
    url
    description
    posterName
    binned
    userPosted
  }
}
`;

const Get_MyPostData = gql`
query {
  userPostedImages{
    id
    url
    description
    posterName
    binned
    userPosted
  }
}
`;

const DELETE_Image = gql`
  mutation deleteEmployee($id: String!) {
    deleteImage(id: $id) {
      id
      url
      description
      posterName
      binned
      userPosted
    }
  }
`;


const GET_UnsplashData = gql`
query unsplashImagesData($pageNum: Int) {
  unsplashImages(pageNum: $pageNum){
  	id
    url
    posterName
    description
    userPosted
    binned
  }
}
`;

export default {
  GET_UnsplashData,
  Get_MyPostData,
  Add_NewPost
 
};