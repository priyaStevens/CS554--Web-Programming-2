import './App.css';
import React, { useState, useEffect } from 'react';

const Error = (props) => {

    return(
        <div>
            <p>
                Error 404: No page found!..
            </p>
        </div>
    )
};

export default Error;