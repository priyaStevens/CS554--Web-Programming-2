import React from 'react'

const Pagination = (props) => {
    // const pageLinks = []
    console.log('i am in pagination');

    // for(let i=0; i<=props.pages; i++){
    //     let active = props.currentpage == i ? 'active' : '';

    //     // pageLinks.push(<li key={i} onClick={()=>props.nextpage(i)}><a href='#'>Next</a></li>)
    // }
   
    return(
        <div>
                {props.currentpage > 1 ? <div onClick={()=>props.nextpage(props.currentpage-1)}><a href='#'>Next</a></div>:''}
                {props.currentpage < props.pages+1 ? <div onClick={()=>props.nextpage(props.currentpage+1)}><a href='#'>Next</a></div>:''}

        </div>
    )

}

export default Pagination;